# SF Process Flow

## Select Available Basket to Invest via SIP
![Select Basket Screenshot](assets/screenshots/select_basket.png)

## Invest Now
![Invest Now Screenshot](assets/screenshots/invest_now.png)

## SIP Trigger Date
![SIP Trigger Date Screenshot](assets/screenshots/sip_trigger_date.png)

## Confirm Investment
![Confirm Investment Screenshot](assets/screenshots/confirm_investment.png)

## LUMPSUM Investment
![Lumpsum Screenshot](assets/screenshots/lumpsum_investment.png)

## DIY Investment
![DIY Investment Screenshot](assets/screenshots/diy_investment.png)

## My Folios
![My Folios Screenshot](assets/screenshots/my_folios.png)

## Order Book
![Order Book Screenshot](assets/screenshots/order_book.png)
